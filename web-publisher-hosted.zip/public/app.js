let files=new Map(), selected="";
const input=$("#file"),label=$("#label"),status=$("#status"),frame=$("#frame"),result=$("#result");
function $(s){return document.querySelector(s)}
input.onchange=()=>loadFile(input.files[0]);
async function loadFile(file){
 if(!file)return;
 if(file.size>5*1024*1024){msg("File maksimal 5 MB.","err");return}
 files.clear();selected=file.name;
 try{
  if(file.name.toLowerCase().endsWith(".zip")){
   const z=await JSZip.loadAsync(file);
   for(const [name,o] of Object.entries(z.files)){
    if(!o.dir){const p=clean(name);if(p&&!p.startsWith("__MACOSX/"))files.set(p,await o.async("uint8array"))}
   }
   if(!index())throw Error("ZIP harus memiliki index.html.");
  }else files.set("index.html",new Uint8Array(await file.arrayBuffer()));
  label.textContent=file.name;$("#preview").disabled=false;$("#publish").disabled=false;
  msg("File siap.","ok");
 }catch(e){files.clear();$("#preview").disabled=true;$("#publish").disabled=true;msg(e.message,"err")}
}
function clean(p){return p.replaceAll("\\","/").split("/").filter(x=>x&&x!="."&&x!="..").join("/")}
function index(){for(const k of files.keys())if(k.toLowerCase()=="index.html")return k}
function mime(n){const e=n.split(".").pop().toLowerCase();return({html:"text/html",css:"text/css",js:"text/javascript",json:"application/json",svg:"image/svg+xml",png:"image/png",jpg:"image/jpeg",jpeg:"image/jpeg",gif:"image/gif",webp:"image/webp"}[e]||"application/octet-stream")}
function url(n){return files.has(n)?URL.createObjectURL(new Blob([files.get(n)],{type:mime(n)})):null}
$("#preview").onclick=()=>{
 let i=index(),html=new TextDecoder().decode(files.get(i));
 html=html.replace(/(src|href)=["']([^"'#]+)["']/gi,(m,a,u)=>{if(/^(https?:|data:|blob:|\/)/i.test(u))return m;let q=resolve(i,u),x=url(q);return x?`${a}="${x}"`:m});
 frame.srcdoc=html;msg("Preview dibuka.","ok");
};
$("#publish").onclick=async()=>{
 const blob=new Blob([await makeZip()],{type:"application/zip"});
 const fd=new FormData();fd.append("file",blob,selected.endsWith(".zip")?selected:"website.zip");
 $("#publish").disabled=true;msg("⏳ Upload dan publish...");
 try{
  const r=await fetch("/api/upload",{method:"POST",body:fd}),d=await r.json();
  if(!r.ok)throw Error(d.error||"Publish gagal");
  result.classList.remove("hidden");
  result.innerHTML=`✅ Website berhasil dipublikasikan!<br><a target="_blank" href="${d.url}">${location.origin+d.url}</a>`;
  msg("Website sudah online.","ok");loadProjects();
 }catch(e){msg("❌ "+e.message,"err")}finally{$("#publish").disabled=false}
};
async function makeZip(){const z=new JSZip();for(const [n,d] of files)z.file(n,d);return z.generateAsync({type:"uint8array"})}
function resolve(base,rel){let d=base.includes("/")?base.slice(0,base.lastIndexOf("/")+1):"",a=(d+rel.split("?")[0].split("#")[0]).split("/"),o=[];for(const p of a){if(!p||p==".")continue;p==".." ? o.pop():o.push(p)}return o.join("/")}
$("#refresh").onclick=loadProjects;
async function loadProjects(){try{const a=await(await fetch("/api/projects")).json();const box=$("#projects");if(!a.length){box.innerHTML='<div class="empty">Belum ada website.</div>';return}box.innerHTML=a.map(p=>`<div class="item"><div><div class="name">${esc(p.name)}</div><div class="date">${new Date(p.createdAt).toLocaleString("id-ID")}</div></div><div class="actions"><a target="_blank" href="${p.url}">🌐 Buka</a><button class="del" onclick="del('${p.id}')">Hapus</button></div></div>`).join("")}catch{}}
async function del(id){if(!confirm("Hapus website ini?"))return;await fetch("/api/projects/"+id,{method:"DELETE"});loadProjects()}
function msg(t,c=""){status.textContent=t;status.className=c}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
loadProjects();
