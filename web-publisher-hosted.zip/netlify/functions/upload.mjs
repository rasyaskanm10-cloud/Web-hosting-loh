import {getStore} from "@netlify/blobs"; import AdmZip from "adm-zip"; import crypto from "node:crypto";
const store=getStore("published-sites"); const MAX=5*1024*1024;
const out=(x,s=200)=>Response.json(x,{status:s});
const clean=p=>p.replaceAll("\\","/").split("/").filter(x=>x&&x!="."&&x!="..").join("/");
export default async req=>{
 if(req.method!=="POST")return out({error:"Method tidak diizinkan."},405);
 try{
  const f=(await req.formData()).get("file"); if(!f)return out({error:"File tidak ditemukan."},400);
  if(f.size>MAX)return out({error:"Maksimal 5 MB."},413);
  const id=crypto.randomBytes(6).toString("hex"), prefix=`sites/${id}/`, bytes=Buffer.from(await f.arrayBuffer()), z=new AdmZip(bytes);
  for(const e of z.getEntries()){if(e.isDirectory)continue;const n=clean(e.entryName);if(!n||n.startsWith("__MACOSX/"))continue;const d=e.getData();if(d.length>MAX)return out({error:"File dalam ZIP terlalu besar."},413);await store.set(prefix+n,d)}
  const {blobs}=await store.list({prefix}); if(!blobs.some(x=>x.key.toLowerCase()===prefix+"index.html"))return out({error:"ZIP harus memiliki index.html."},400);
  const meta={id,name:f.name,createdAt:new Date().toISOString(),url:`/site/${id}/`};await store.setJSON(prefix+"__meta.json",meta);
  return out(meta);
 }catch(e){console.error(e);return out({error:e.message},500)}
};
export const config={path:"/api/upload"};
